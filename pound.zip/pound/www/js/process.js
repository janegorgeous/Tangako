
let process = {
	menu:function(){
		let content = <div>   
		<h2>Pounds To Kilograms<br /> Converter Using Javascript</h2>
			<table width="100%" cellpadding="5" cellspacing="5">
			<tr>
		<td><label>Enter a value</label></td>
		<td><input type="number" id="values" class="txt_Number" onkeypress="return numberTo_Convert(event)" required autofocus="autofocus" /></td>
	</tr>
	<tr>
		<td colspan="2"></td>
	</tr>
	<tr>
		<td colspan="2">
			<button class="btn_convert" id="convert" onClick={display_result}>Convert</button>
			<button class="btn_clear" onClick={clear_text}>Clear</button>
		</td>
	</tr>
</table>
 
<div id="result"></div>

		</div>;
		ReactDOM.render(content,document.getElementById('root'));
	}
}

process.menu();

document.onload = function() {
document.getElementById('values').focus();
	};
	function convert_to_pounds(number_value)
	{
 
	return (number_value * 0.453592 );
	 }
function display_result() {
	 var kilograms = document.getElementById("values").value;
	 var result = convert_to_pounds(kilograms);
 
	 if (document.getElementById("values").value == '') {
	alert("Cannot be empty. Kindly type your value to convert.");
	document.getElementById('values').focus();
 
	}
	 else {
	 document.getElementById('result').innerHTML = kilograms + " pound(s) is equal to "
	+ result.toFixed(2) + " kilogram(s). ";
	 }
}
function clear_text() {
	 document.getElementById("values").value="";
	 document.getElementById("result").innerHTML="";
	 document.getElementById("values").focus();
}
function numberTo_Convert(evt) {
evt = (evt) ? evt : window.event;
var charCode = (evt.which) ? evt.which : evt.keyCode;
if (charCode > 31 && (charCode < 48 || charCode > 57)) {
return false;
}
return true;
}